Il suffit d'avoir téléchargé les trois fichiers csv du projet et de les mettre dans votre environement de travail.
Ensuite lancez script_nettoyage.Rmd
Et enfin script_grahique.Rmd

